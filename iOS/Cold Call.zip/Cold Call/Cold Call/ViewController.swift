//
//  ViewController.swift
//  Cold Call
//
//  Created by MJ Norona on 7/5/17.
//  Copyright © 2017 MJ Norona. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var names = ["MJ", "Jazz", "Marc", "Gemma", "Paciencia"]
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBAction func coldButtonPressed(_ sender: Any) {
        let rand = Int(arc4random_uniform(5))
        updateUI(index: rand)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func updateUI(index: Int) {
        nameLabel.text = names[index]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

