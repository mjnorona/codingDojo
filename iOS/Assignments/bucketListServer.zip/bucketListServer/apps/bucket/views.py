from django.shortcuts import render, HttpResponse
from django.core import serializers
from .models import Task

# Create your views here.
def index(request):
    return render(request, 'bucket/index.html')

def tasks(request):
    
    data = serializers.serialize('json', Task.objects.all())
    return HttpResponse(data, content_type = 'application/json')