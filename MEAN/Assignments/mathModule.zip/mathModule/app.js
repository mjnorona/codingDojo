var my_module = require('./mathlibs')();
console.log(my_module)
console.log(my_module.add(1,2))
console.log(my_module.multiply(3,5))
console.log(my_module.square(3))
console.log(my_module.random(3,87))