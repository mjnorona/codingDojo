from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, "port/index.html")

def test(request):
    return render(request, "port/testimonials.html")